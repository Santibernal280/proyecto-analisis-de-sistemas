package com.corhuila.Juan_Valdez.IRepository;

import com.corhuila.Juan_Valdez.Entity.Cliente;
import com.corhuila.Juan_Valdez.Entity.ServicioCliente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IServicioClienteRepository extends JpaRepository<ServicioCliente, Integer> {
}
