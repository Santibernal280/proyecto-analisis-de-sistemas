package com.corhuila.Juan_Valdez.IRepository;

import com.corhuila.Juan_Valdez.Entity.Cliente;
import com.corhuila.Juan_Valdez.Entity.Servicio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IServicioRepository extends JpaRepository<Servicio, Integer> {
}

