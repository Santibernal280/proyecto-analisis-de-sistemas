package com.corhuila.Juan_Valdez.IRepository;

import com.corhuila.Juan_Valdez.Entity.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IClienteRepository extends JpaRepository<Cliente, Integer> {
}
